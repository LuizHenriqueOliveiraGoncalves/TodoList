package com.example.todolist2;

import android.app.Application;
import android.view.View;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class ListaViewModel extends AndroidViewModel {

    private ListaRepository repository;
    private LiveData<List<Lista>> allListas;

    public ListaViewModel(Application application) {
        super(application);
        repository = new ListaRepository(application);
        allListas = repository.getAllListas();
    }

    public void insert(Lista lista) {
        repository.insert(lista);
    }

    public LiveData<List<Lista>> getAllListas() {
        return allListas;
    }

}
