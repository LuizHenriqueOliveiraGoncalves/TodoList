package com.example.todolist2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editTextTitulo, editTextDescricao;
    private Button buttonAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTitulo = findViewById(R.id.editTextTitulo);
        editTextDescricao = findViewById(R.id.editTextDescricao);
        buttonAdd = findViewById(R.id.buttonAdd);
        Button btnVerLista = findViewById(R.id.btnVerLista);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProduct();
            }
        });


        btnVerLista.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this, ListaActivity.class));
            }
        });
    }

    private void saveProduct() {
        String titulo = editTextTitulo.getText().toString().trim();
        String descricao = editTextDescricao.getText().toString().trim();


        if (titulo.isEmpty() || descricao.isEmpty() ) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }



        Lista lista = new Lista(titulo, descricao);
        ListaViewModel listaViewModel = new ListaViewModel(getApplication());
        listaViewModel.insert(lista);

        Toast.makeText(this, "Item salvo", Toast.LENGTH_SHORT).show();
        limparCampos();
    }

    private void limparCampos() {
        editTextTitulo.setText("");
        editTextDescricao.setText("");

        editTextTitulo.requestFocus();
    }
}


