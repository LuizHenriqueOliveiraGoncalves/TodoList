package com.example.todolist2;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;

public class ListaRepository {

    private ListaDao listaDao;
    private LiveData<List<Lista>> allListas;

    public ListaRepository(Application application) {
        ListaDatabase database = ListaDatabase.getDatabase(application);
        listaDao = database.listaDao();
        allListas = listaDao.getAllLista();
    }

    public void insert(Lista lista) {
        new Thread(() -> listaDao.insert(lista)).start();
    }

    public LiveData<List<Lista>> getAllListas() {
        return allListas;
    }
}
