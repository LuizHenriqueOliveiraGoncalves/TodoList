package com.example.todolist2;


import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Lista.class}, version = 1)
public abstract class ListaDatabase extends RoomDatabase {
    public abstract ListaDao listaDao();

    private static volatile ListaDatabase INSTANCE;

    public static ListaDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (ListaDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    ListaDatabase.class, "lista_database")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}