package com.example.todolist2;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ListaDao {
    @Insert
    void insert(Lista lista);

    @Query("SELECT * FROM listas ORDER BY titulo ASC")
    LiveData<List<Lista>> getAllLista();

    @Query("SELECT * FROM listas WHERE titulo LIKE :search ")
    LiveData<List<Lista>> searchLista(String search);

}
