package com.example.todolist2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public  class ListaAdapter extends RecyclerView.Adapter<ListaAdapter.ListasViewHolder>{
    private List<Lista> listas;

    public ListaAdapter(List<Lista> listas) { this.listas = listas;}

    @NonNull
    @Override
    public ListasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item, parent, false);
        return new ListasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListasViewHolder holder, int position) {
        Lista lista = listas.get(position);
        holder.textViewTitulo.setText(lista.getTitulo());
        holder.textViewDescricao.setText(lista.getDescricao());

    }

    @Override
    public int getItemCount() {
        return listas.size();
    }

    static class ListasViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitulo, textViewDescricao;

        public ListasViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitulo = itemView.findViewById(R.id.editTextTitulo);
            textViewDescricao = itemView.findViewById(R.id.editTextDescricao);

        }
    }
}