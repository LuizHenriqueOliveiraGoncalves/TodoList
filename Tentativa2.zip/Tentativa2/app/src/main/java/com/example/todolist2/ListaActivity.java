package com.example.todolist2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ListaActivity extends AppCompatActivity {
    private ListaViewModel productViewModel;
    private ListaAdapter adapter;
    private List<Lista> listas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ListaAdapter(listas);
        recyclerView.setAdapter(adapter);

        Button buttonAddNew = findViewById(R.id.buttonAddNew);

        buttonAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListaActivity.this, MainActivity.class));
            }
        });

        productViewModel = new ViewModelProvider(this).get(ListaViewModel.class);
        productViewModel.getAllListas().observe(this, products -> {
            this.listas.clear();
            this.listas.addAll(products);
            adapter.notifyDataSetChanged();

            TextView textViewEmpty = findViewById(R.id.textViewEmpty);
            if (products.isEmpty()) {
                textViewEmpty.setVisibility(View.VISIBLE);
            } else {
                textViewEmpty.setVisibility(View.GONE);
            }
        });

        Button btnBack = findViewById(R.id.btnBackToRegister);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retorna para a MainActivity (tela de cadastro)
                startActivity(new Intent(ListaActivity.this, MainActivity.class));
            }
        });



    }


}

